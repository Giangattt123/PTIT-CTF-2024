#!/bin/sh


# Change directory and run Flask
cd /app && flask run -h 0.0.0.0 -p 8887